# Google Maps + Prisma

Demo application showing how to use Prisma to persist and load data with Postgres.
