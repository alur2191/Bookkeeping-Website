import "../styles.css";
import "@reach/combobox/styles.css";

export default function MyApp({ Component, pageProps }: any) {
  return <Component {...pageProps} />;
}
